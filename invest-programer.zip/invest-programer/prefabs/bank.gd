extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_exit_pressed() -> void:
	get_tree().change_scene_to_file("res://main.tscn")


func _on_menu_pressed() -> void:
	get_tree().change_scene_to_file("res://prefabs/tile_screen.tscn")

func _on_logo_bank_pressed() -> void:
	get_tree().change_scene_to_file("res://prefabs/bank.tscn")


func _on_invest_pressed() -> void:
	pass


func _on_saldo_pressed() -> void:
	pass # Replace with function body.
